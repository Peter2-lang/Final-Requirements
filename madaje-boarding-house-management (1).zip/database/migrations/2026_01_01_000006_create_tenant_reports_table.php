<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tenant_reports', function (Blueprint $table) {
            $table->string('id', 80)->primary();
            $table->string('tenant_id', 80);
            $table->string('category', 80);
            $table->string('title', 180);
            $table->text('details');
            $table->date('report_date');
            $table->enum('status', ['Open', 'In Progress', 'Resolved'])->default('Open');
            $table->timestamps();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_reports');
    }
};