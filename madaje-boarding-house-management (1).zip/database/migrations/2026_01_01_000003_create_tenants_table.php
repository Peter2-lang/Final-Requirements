<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('tenants', function (Blueprint $table) {
            $table->string('id', 80)->primary();
            $table->string('name', 150);
            $table->string('email', 150);
            $table->string('phone', 40)->nullable();
            $table->string('room_id', 80);
            $table->date('start_date');
            $table->decimal('monthly_rent', 10, 2);
            $table->string('account_id', 80)->nullable();
            $table->timestamps();
            $table->foreign('room_id')->references('id')->on('rooms');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenants');
    }
};