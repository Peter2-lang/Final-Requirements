<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('rooms', function (Blueprint $table) {
            $table->string('id', 80)->primary();
            $table->string('name', 100);
            $table->string('room_number', 40)->unique();
            $table->string('type', 80);
            $table->decimal('monthly_rate', 10, 2);
            $table->integer('capacity')->default(1);
            $table->text('inclusions')->nullable();
            $table->enum('status', ['Available', 'Occupied', 'Maintenance'])->default('Available');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rooms');
    }
};