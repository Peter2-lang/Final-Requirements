<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->string('id', 80)->primary();
            $table->string('tenant_id', 80);
            $table->string('room_id', 80);
            $table->decimal('amount', 10, 2);
            $table->enum('method', ['Cash', 'GCash', 'E-cash']);
            $table->string('reference', 150)->nullable();
            $table->date('payment_date');
            $table->enum('status', ['Pending', 'Verified'])->default('Pending');
            $table->timestamps();
            $table->foreign('tenant_id')->references('id')->on('tenants')->cascadeOnDelete();
            $table->foreign('room_id')->references('id')->on('rooms')->cascadeOnDelete();
            $table->index(['room_id', 'payment_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};