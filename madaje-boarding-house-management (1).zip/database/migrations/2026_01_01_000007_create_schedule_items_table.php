<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('schedule_items', function (Blueprint $table) {
            $table->string('id', 80)->primary();
            $table->string('title', 180);
            $table->date('schedule_date');
            $table->time('schedule_time');
            $table->string('category', 80);
            $table->text('details')->nullable();
            $table->boolean('visible_to_tenants')->default(true);
            $table->timestamps();
            $table->index('schedule_date');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('schedule_items');
    }
};