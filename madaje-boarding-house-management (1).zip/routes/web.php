<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

function bh_property(): array
{
    $profile = DB::table('property_profiles')->latest('id')->first();
    if ($profile) {
        return [
            'name' => $profile->name,
            'address' => $profile->address,
            'map_url' => $profile->map_url,
            'manager' => $profile->manager,
            'phone' => $profile->phone,
            'notes' => $profile->notes ?? '',
        ];
    }
    return [
        'name' => "Madaje's Boarding House",
        'address' => '95WX+QQP Hinunangan, Southern Leyte. Nearby Address: San Pedro Street, Hinunangan, Southern Leyte',
        'map_url' => 'https://www.google.com/maps?q=10.3969560,125.1994614&z=18&output=embed',
        'manager' => 'Mariel Daje',
        'phone' => '0918 234 8899',
        'notes' => '',
    ];
}

function bh_rooms() { return DB::table('rooms')->orderBy('room_number')->get(); }
function bh_tenants() { return DB::table('tenants')->orderBy('name')->get(); }
function bh_payments() { return DB::table('payments')->orderByDesc('payment_date')->get(); }
function bh_reports() { return DB::table('tenant_reports')->orderByDesc('report_date')->get(); }
function bh_accounts() { return DB::table('accounts')->orderBy('role')->orderBy('username')->get(); }
function bh_schedules($tenantVisibleOnly = false) {
    $query = DB::table('schedule_items')->orderBy('schedule_date')->orderBy('schedule_time');
    return $tenantVisibleOnly ? $query->where('visible_to_tenants', true)->get() : $query->get();
}
function bh_shared_monthly($roomId): float {
    $room = DB::table('rooms')->where('id', $roomId)->first();
    if (! $room) return 0;
    $tenantCount = max(1, DB::table('tenants')->where('room_id', $roomId)->count());
    return (float) $room->monthly_rate / $tenantCount;
}

Route::get('/', fn () => view('auth.login', ['property' => bh_property()]));
Route::get('/login', fn () => view('auth.login', ['property' => bh_property()]))->name('login');

Route::post('/login', function (Request $request) {
    $account = DB::table('accounts')->where('role', $request->input('role'))->where('username', $request->input('username'))->first();
    if (! $account || $account->password_hash !== $request->input('password')) {
        return back()->withErrors(['login' => 'Invalid username or password.']);
    }
    session(['account_id' => $account->id, 'role' => $account->role, 'tenant_id' => $account->tenant_id, 'username' => $account->username]);
    return redirect($account->role === 'admin' ? '/admin/dashboard' : '/tenant/dashboard');
});

Route::post('/logout', function () { session()->flush(); return redirect('/login'); });

Route::prefix('admin')->group(function () {
    Route::get('/dashboard', fn () => view('admin.dashboard', ['property' => bh_property(), 'rooms' => bh_rooms(), 'tenants' => bh_tenants(), 'payments' => bh_payments(), 'reports' => bh_reports()]));
    Route::get('/rooms', fn () => view('admin.rooms', ['property' => bh_property(), 'rooms' => bh_rooms(), 'tenants' => bh_tenants()]));
    Route::post('/rooms', function (Request $request) {
        DB::table('rooms')->insert(['id' => 'room-'.Str::uuid(), 'name' => $request->name, 'room_number' => $request->room_number, 'type' => $request->type ?? 'Standard', 'monthly_rate' => $request->monthly_rate ?? 0, 'capacity' => $request->capacity ?? 1, 'inclusions' => $request->inclusions, 'status' => $request->status ?? 'Available', 'created_at' => now(), 'updated_at' => now()]);
        return back();
    });
    Route::delete('/rooms/{id}', function ($id) { DB::table('rooms')->where('id', $id)->delete(); return back(); });

    Route::get('/tenants', fn () => view('admin.tenants', ['property' => bh_property(), 'rooms' => bh_rooms(), 'tenants' => bh_tenants()]));
    Route::post('/tenants', function (Request $request) {
        DB::table('tenants')->insert(['id' => 'tenant-'.Str::uuid(), 'name' => $request->name, 'email' => $request->email, 'phone' => $request->phone, 'room_id' => $request->room_id, 'start_date' => $request->start_date ?? now()->toDateString(), 'monthly_rent' => bh_shared_monthly($request->room_id), 'created_at' => now(), 'updated_at' => now()]);
        DB::table('rooms')->where('id', $request->room_id)->update(['status' => 'Occupied']);
        return back();
    });
    Route::delete('/tenants/{id}', function ($id) { DB::table('tenants')->where('id', $id)->delete(); return back(); });

    Route::get('/payments', fn () => view('admin.payments', ['property' => bh_property(), 'rooms' => bh_rooms(), 'tenants' => bh_tenants(), 'payments' => bh_payments()]));
    Route::post('/payments', function (Request $request) {
        $tenant = DB::table('tenants')->where('id', $request->tenant_id)->first();
        if ($tenant) {
            DB::table('payments')->insert(['id' => 'pay-'.Str::uuid(), 'tenant_id' => $tenant->id, 'room_id' => $tenant->room_id, 'amount' => $request->amount ?? bh_shared_monthly($tenant->room_id), 'method' => $request->method ?? 'Cash', 'reference' => $request->reference, 'payment_date' => now()->toDateString(), 'status' => $request->status ?? 'Verified', 'created_at' => now(), 'updated_at' => now()]);
        }
        return back();
    });

    Route::get('/calendar', fn () => view('admin.calendar', ['property' => bh_property(), 'scheduleItems' => bh_schedules()]));
    Route::post('/calendar', function (Request $request) {
        DB::table('schedule_items')->insert(['id' => 'sched-'.Str::uuid(), 'title' => $request->title, 'schedule_date' => $request->schedule_date, 'schedule_time' => $request->schedule_time, 'category' => $request->category ?? 'Reminder', 'details' => $request->details, 'visible_to_tenants' => $request->boolean('visible_to_tenants'), 'created_at' => now(), 'updated_at' => now()]);
        return back();
    });

    Route::get('/reports', fn () => view('admin.reports', ['property' => bh_property(), 'reports' => bh_reports(), 'tenants' => bh_tenants()]));
    Route::put('/reports/{id}', function (Request $request, $id) { DB::table('tenant_reports')->where('id', $id)->update(['status' => $request->status, 'updated_at' => now()]); return back(); });

    Route::get('/users', fn () => view('admin.users', ['property' => bh_property(), 'accounts' => bh_accounts(), 'tenants' => bh_tenants()]));
    Route::post('/users', function (Request $request) {
        DB::table('accounts')->insert(['id' => 'acct-'.Str::uuid(), 'role' => 'tenant', 'username' => $request->username, 'password_hash' => $request->password, 'tenant_id' => $request->tenant_id, 'created_at' => now(), 'updated_at' => now()]);
        return back();
    });

    Route::get('/profile', fn () => view('admin.profile', ['property' => bh_property()]));
    Route::put('/profile', function (Request $request) {
        DB::table('property_profiles')->truncate();
        DB::table('property_profiles')->insert(['name' => $request->name, 'address' => $request->address, 'map_url' => $request->map_url, 'manager' => $request->manager, 'phone' => $request->phone, 'notes' => $request->notes, 'created_at' => now(), 'updated_at' => now()]);
        return back();
    });
});

Route::prefix('tenant')->group(function () {
    Route::get('/dashboard', function () {
        $tenant = DB::table('tenants')->where('id', session('tenant_id'))->first();
        $room = $tenant ? DB::table('rooms')->where('id', $tenant->room_id)->first() : null;
        return view('tenant.dashboard', ['property' => bh_property(), 'tenant' => $tenant, 'room' => $room, 'availableRooms' => bh_rooms()->where('status', 'Available'), 'balance' => 0, 'verifiedPaid' => 0, 'sharedMonthly' => $room ? bh_shared_monthly($room->id) : 0]);
    });
    Route::get('/calendar', fn () => view('tenant.calendar', ['property' => bh_property(), 'scheduleItems' => bh_schedules(true)]));
    Route::get('/payment', function () { $tenant = DB::table('tenants')->where('id', session('tenant_id'))->first(); $payments = $tenant ? DB::table('payments')->where('room_id', $tenant->room_id)->orderByDesc('payment_date')->get() : collect(); return view('tenant.payment', ['property' => bh_property(), 'payments' => $payments, 'sharedMonthly' => $tenant ? bh_shared_monthly($tenant->room_id) : 0]); });
    Route::post('/payment', function (Request $request) { $tenant = DB::table('tenants')->where('id', session('tenant_id'))->first(); if ($tenant) DB::table('payments')->insert(['id' => 'pay-'.Str::uuid(), 'tenant_id' => $tenant->id, 'room_id' => $tenant->room_id, 'amount' => $request->amount ?? bh_shared_monthly($tenant->room_id), 'method' => $request->method ?? 'GCash', 'reference' => $request->reference, 'payment_date' => now()->toDateString(), 'status' => 'Pending', 'created_at' => now(), 'updated_at' => now()]); return back(); });
    Route::get('/reports', fn () => view('tenant.reports', ['property' => bh_property(), 'reports' => DB::table('tenant_reports')->where('tenant_id', session('tenant_id'))->get()]));
    Route::post('/reports', function (Request $request) { DB::table('tenant_reports')->insert(['id' => 'report-'.Str::uuid(), 'tenant_id' => session('tenant_id'), 'category' => $request->category, 'title' => $request->title, 'details' => $request->details, 'report_date' => now()->toDateString(), 'status' => 'Open', 'created_at' => now(), 'updated_at' => now()]); return back(); });
    Route::get('/profile', fn () => view('tenant.profile', ['property' => bh_property(), 'tenant' => DB::table('tenants')->where('id', session('tenant_id'))->first(), 'account' => DB::table('accounts')->where('id', session('account_id'))->first()]));
});