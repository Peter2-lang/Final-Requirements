<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantReport extends Model
{
    protected $table = 'tenant_reports';
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['id', 'tenant_id', 'category', 'title', 'details', 'report_date', 'status'];
}