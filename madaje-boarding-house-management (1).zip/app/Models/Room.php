<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
    public $incrementing = false;
    protected $keyType = 'string';
    protected $fillable = ['id', 'name', 'room_number', 'type', 'monthly_rate', 'capacity', 'inclusions', 'status'];
}