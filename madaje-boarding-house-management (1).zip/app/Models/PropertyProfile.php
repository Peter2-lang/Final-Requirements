<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PropertyProfile extends Model
{
    protected $fillable = ['name', 'address', 'map_url', 'manager', 'phone', 'notes'];
}